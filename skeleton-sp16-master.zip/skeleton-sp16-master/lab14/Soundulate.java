import java.util.ArrayList;

public class Soundulate {

	public static void main(String[] args) {
	}
} 