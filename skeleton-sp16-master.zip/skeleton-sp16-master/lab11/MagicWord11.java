public class MagicWord11 {
    public static String magicWord() {
        /* replace magicWord with the magic word or use "early"
        *  if you are submitting early */

        /* Due to late release, the magic word is: bean */
        String magicWord = "bean";
        return magicWord;
    }
} 
