public class MagicWordEC1 {
	public static String magicWord() {
		/* replace magicWord with the magic word given to you when
		 * you finished the survey. */
		String magicWord = "";
		return magicWord;
	}
} 