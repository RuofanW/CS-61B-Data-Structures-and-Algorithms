public class MagicWord13 {
    public static String magicWord() {

        /* replace magicWord with the magic word or use "early"
         *  if you are submitting early */

        /* Magic word given away for free since we won't cover this week's
         * lecture material until the Wednesday of lab week. */

        String magicWord = "oneweekleft";
        return magicWord;
    }
} 
