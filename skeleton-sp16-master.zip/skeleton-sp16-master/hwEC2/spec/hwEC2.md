If you went to lecture 1, use the lecture 1 magic word. 
If you went to lecture 2, use the lecture 2 magic word. 
If you went to the hkn office, use the hkn magic word.
