public class MagicWordEC2 {
	public static String magicWord() {
		/* replace magicWord with the magic word given to you when
		 * you finished the survey. */
		String magicWord = "";
		return magicWord;
	}
} 