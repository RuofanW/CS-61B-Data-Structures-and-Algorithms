package lab9;

public class MagicWord9 {
    public static String magicWord() {
        /* Since Spring Break is happening, lab attendance is not
         * required. You may simply submit this file. */
        String magicWord = "springbreak";
        return magicWord;
    }
} 
