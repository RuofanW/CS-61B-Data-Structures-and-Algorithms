public class MagicWord5 {
	public static String magicWord() {
		/* Replace magicWord with the magic word given in lab.
		 * If you are submitting early, just put in "early" */
		String magicWord = "";
		return magicWord;
	}
} 