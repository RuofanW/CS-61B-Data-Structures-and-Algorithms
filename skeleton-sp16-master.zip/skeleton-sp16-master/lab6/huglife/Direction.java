package huglife;

public enum Direction {
    TOP, BOTTOM, LEFT, RIGHT
}